﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static PTISystem.MainWindow;

namespace PTISystem
{
    public partial class StopOptions : Form
    {
        public DialogResult Result { get; private set; }

        private Stop theStop;
        private CRUDOption option;

        public StopOptions(CRUDOption option, Stop theStop)
        {
            InitializeComponent();

            Result = DialogResult.No;

            this.option = option;
            if (option == CRUDOption.Update)
            {
                this.theStop = theStop;
                textBoxStopName.Text = theStop.NameGroup;
                textBoxStopDirection.Text = theStop.Direction;
                textBoxStopStreet.Text = theStop.Street;
            }
            else
            {
                CreateNewStop();
            }
        }

        private void CreateNewStop()
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                NameGroup theNameGroup = new NameGroup();
                theNameGroup.Name = "  ";
                if (DBEntities.NameGroup.Where(n => n.Name == theNameGroup.Name).Count() == 0)
                DBEntities.NameGroup.Add(theNameGroup);

                theStop = new Stop();
                theStop.NameGroup = theNameGroup.Name;
                theStop.Direction = "  ";
                theStop.Street = "  ";

                DBEntities.Stop.Add(theStop);
                DBEntities.SaveChanges();

                theStop = DBEntities.Stop.FirstOrDefault(r => r.NameGroup == "  " && r.Direction == "  " && r.Street == "  ");
            }
        }

        private void buttonCommit_Click(object sender, EventArgs e)
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                if (string.IsNullOrEmpty(textBoxStopName.Text.Trim()))
                {
                    MessageBox.Show("Please provide name for the stop.");
                    return;
                }
                else if (string.IsNullOrEmpty(textBoxStopDirection.Text.Trim()))
                {
                    MessageBox.Show("Please provide direction for the stop.");
                    return;
                }
                else if (string.IsNullOrEmpty(textBoxStopStreet.Text.Trim()))
                {
                    MessageBox.Show("Please provide street info for the stop.");
                    return;
                }
                else if (DBEntities.Stop.Where(r => r.NameGroup == theStop.NameGroup && r.Direction == theStop.Direction && r.Id != theStop.Id).Count() != 0)
                {
                    MessageBox.Show("Stop with such name and direction already exists.");
                    return;
                }
                else 
                {
                    NameGroup theNameGroup = new NameGroup();
                    theNameGroup.Name = theStop.NameGroup;
                    if (DBEntities.NameGroup.Where(n => n.Name == theNameGroup.Name).Count() == 0)
                        DBEntities.NameGroup.Add(theNameGroup);

                    DBEntities.Stop.First(s => s.Id == theStop.Id).NameGroup = theStop.NameGroup;
                    DBEntities.Stop.First(s => s.Id == theStop.Id).Direction = theStop.Direction;
                    DBEntities.Stop.First(s => s.Id == theStop.Id).Street = theStop.Street;
                    DBEntities.SaveChanges();
                }
            }

            Result = DialogResult.Yes;
            this.Close();
        }

        private void textBoxStopName_TextChanged(object sender, EventArgs e)
        {
            theStop.NameGroup = textBoxStopName.Text;
        }

        private void textBoxStopDirection_TextChanged(object sender, EventArgs e)
        {
            theStop.Direction = textBoxStopDirection.Text;
        }

        private void textBoxStopStreet_TextChanged(object sender, EventArgs e)
        {
            theStop.Street = textBoxStopStreet.Text;
        }
    }
}
