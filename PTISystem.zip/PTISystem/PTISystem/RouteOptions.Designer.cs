﻿namespace PTISystem
{
    partial class RouteOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCommit = new System.Windows.Forms.Button();
            this.buttonAddStop = new System.Windows.Forms.Button();
            this.buttonRemoveStop = new System.Windows.Forms.Button();
            this.labelOtherStops = new System.Windows.Forms.Label();
            this.listBoxOtherStops = new System.Windows.Forms.ListBox();
            this.listBoxRouteStops = new System.Windows.Forms.ListBox();
            this.labelRouteStops = new System.Windows.Forms.Label();
            this.textBoxRouteName = new System.Windows.Forms.TextBox();
            this.labelParkName = new System.Windows.Forms.Label();
            this.textBoxDuration = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonCommit
            // 
            this.buttonCommit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonCommit.Location = new System.Drawing.Point(280, 28);
            this.buttonCommit.Name = "buttonCommit";
            this.buttonCommit.Size = new System.Drawing.Size(60, 24);
            this.buttonCommit.TabIndex = 27;
            this.buttonCommit.Text = "Done";
            this.buttonCommit.UseVisualStyleBackColor = true;
            this.buttonCommit.Click += new System.EventHandler(this.buttonCommit_Click);
            // 
            // buttonAddStop
            // 
            this.buttonAddStop.Location = new System.Drawing.Point(181, 159);
            this.buttonAddStop.Name = "buttonAddStop";
            this.buttonAddStop.Size = new System.Drawing.Size(46, 24);
            this.buttonAddStop.TabIndex = 24;
            this.buttonAddStop.Text = "<--";
            this.buttonAddStop.UseVisualStyleBackColor = true;
            this.buttonAddStop.Click += new System.EventHandler(this.buttonAddStop_Click);
            // 
            // buttonRemoveStop
            // 
            this.buttonRemoveStop.Location = new System.Drawing.Point(181, 129);
            this.buttonRemoveStop.Name = "buttonRemoveStop";
            this.buttonRemoveStop.Size = new System.Drawing.Size(46, 24);
            this.buttonRemoveStop.TabIndex = 23;
            this.buttonRemoveStop.Text = "-->";
            this.buttonRemoveStop.UseVisualStyleBackColor = true;
            this.buttonRemoveStop.Click += new System.EventHandler(this.buttonRemoveStop_Click);
            // 
            // labelOtherStops
            // 
            this.labelOtherStops.AutoSize = true;
            this.labelOtherStops.Location = new System.Drawing.Point(230, 83);
            this.labelOtherStops.Name = "labelOtherStops";
            this.labelOtherStops.Size = new System.Drawing.Size(66, 13);
            this.labelOtherStops.TabIndex = 21;
            this.labelOtherStops.Text = "Other Stops:";
            // 
            // listBoxOtherStops
            // 
            this.listBoxOtherStops.FormattingEnabled = true;
            this.listBoxOtherStops.Location = new System.Drawing.Point(233, 99);
            this.listBoxOtherStops.Name = "listBoxOtherStops";
            this.listBoxOtherStops.Size = new System.Drawing.Size(162, 121);
            this.listBoxOtherStops.TabIndex = 20;
            // 
            // listBoxRouteStops
            // 
            this.listBoxRouteStops.FormattingEnabled = true;
            this.listBoxRouteStops.Location = new System.Drawing.Point(11, 100);
            this.listBoxRouteStops.Name = "listBoxRouteStops";
            this.listBoxRouteStops.Size = new System.Drawing.Size(164, 121);
            this.listBoxRouteStops.TabIndex = 19;
            // 
            // labelRouteStops
            // 
            this.labelRouteStops.AutoSize = true;
            this.labelRouteStops.Location = new System.Drawing.Point(11, 83);
            this.labelRouteStops.Name = "labelRouteStops";
            this.labelRouteStops.Size = new System.Drawing.Size(69, 13);
            this.labelRouteStops.TabIndex = 18;
            this.labelRouteStops.Text = "Route Stops:";
            // 
            // textBoxRouteName
            // 
            this.textBoxRouteName.Location = new System.Drawing.Point(81, 6);
            this.textBoxRouteName.Name = "textBoxRouteName";
            this.textBoxRouteName.Size = new System.Drawing.Size(77, 20);
            this.textBoxRouteName.TabIndex = 17;
            // 
            // labelParkName
            // 
            this.labelParkName.AutoSize = true;
            this.labelParkName.Location = new System.Drawing.Point(12, 9);
            this.labelParkName.Name = "labelParkName";
            this.labelParkName.Size = new System.Drawing.Size(38, 13);
            this.labelParkName.TabIndex = 16;
            this.labelParkName.Text = "Name:";
            // 
            // textBoxDuration
            // 
            this.textBoxDuration.Location = new System.Drawing.Point(80, 36);
            this.textBoxDuration.Name = "textBoxDuration";
            this.textBoxDuration.Size = new System.Drawing.Size(78, 20);
            this.textBoxDuration.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Duration:";
            // 
            // RouteOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 233);
            this.Controls.Add(this.textBoxDuration);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCommit);
            this.Controls.Add(this.buttonAddStop);
            this.Controls.Add(this.buttonRemoveStop);
            this.Controls.Add(this.labelOtherStops);
            this.Controls.Add(this.listBoxOtherStops);
            this.Controls.Add(this.listBoxRouteStops);
            this.Controls.Add(this.labelRouteStops);
            this.Controls.Add(this.textBoxRouteName);
            this.Controls.Add(this.labelParkName);
            this.Name = "RouteOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RouteOptions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCommit;
        private System.Windows.Forms.Button buttonAddStop;
        private System.Windows.Forms.Button buttonRemoveStop;
        private System.Windows.Forms.Label labelOtherStops;
        private System.Windows.Forms.ListBox listBoxOtherStops;
        private System.Windows.Forms.ListBox listBoxRouteStops;
        private System.Windows.Forms.Label labelRouteStops;
        private System.Windows.Forms.TextBox textBoxRouteName;
        private System.Windows.Forms.Label labelParkName;
        private System.Windows.Forms.TextBox textBoxDuration;
        private System.Windows.Forms.Label label1;
    }
}