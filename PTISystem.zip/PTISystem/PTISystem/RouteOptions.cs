﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static PTISystem.MainWindow;

namespace PTISystem
{
    public partial class RouteOptions : Form
    {
        public DialogResult Result { get; private set; }

        private Route theRoute;
        private CRUDOption option;

        public RouteOptions(CRUDOption option, Route theRoute)
        {
            InitializeComponent();
            Result = DialogResult.No;

            this.option = option;
            if (option == CRUDOption.Update)
            {
                this.theRoute = theRoute;
                textBoxDuration.Text = theRoute.RunningTime.ToString();
                textBoxRouteName.Text = theRoute.Name;
                PopulateRouteStops();
                PopulateOtherStops();
            }
            else
            {
                CreateNewRoute();
                PopulateOtherStops();
            }

        }

        private void CreateNewRoute()
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                theRoute = new Route();
                theRoute.Name = "  ";
                theRoute.RunningTime = 15;

                DBEntities.Route.Add(theRoute);
                DBEntities.SaveChanges();

                theRoute = DBEntities.Route.FirstOrDefault(r => r.Name == "  ");
            }
        }

        private void PopulateRouteStops()
        {
            listBoxRouteStops.Items.Clear();

            foreach (var stop in theRoute.Stop)
            {
                listBoxRouteStops.Items.Add(stop.NameGroup + " --> " + stop.Direction);
            }
        }

        private void PopulateOtherStops()
        {
            listBoxOtherStops.Items.Clear();

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                int[] routeStops = theRoute.Stop.Select(s => s.Id).ToArray();

                foreach (var stop in DBEntities.Stop)
                {
                    if (!routeStops.Contains(stop.Id))
                    {
                        listBoxOtherStops.Items.Add(stop.NameGroup + " --> " + stop.Direction);
                    }                    
                }
            }
        }

        private void buttonCommit_Click(object sender, EventArgs e)
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                DBEntities.Route.FirstOrDefault(r => r.Name == theRoute.Name).Name = textBoxRouteName.Text;
                int i;

                if (string.IsNullOrEmpty(textBoxRouteName.Text.Trim()))
                {
                    MessageBox.Show("Please provide name for the route.");
                    return;
                }
                else if (string.IsNullOrEmpty(textBoxDuration.Text.Trim()) || !int.TryParse(textBoxDuration.Text, out i) || i < 5)
                {
                    MessageBox.Show("Invalid duration time entered!");
                    return;
                }
                else if (DBEntities.Route.Where(r => r.Id != theRoute.Id).Select(r => r.Name).Contains(theRoute.Name))
                {
                    MessageBox.Show("Route with such name already exists.");
                    return;
                }
                else DBEntities.SaveChanges();
            }

            Result = DialogResult.Yes;
            this.Close();
        }

        private void buttonRemoveStop_Click(object sender, EventArgs e)
        {
            if (listBoxRouteStops.SelectedItem == null || theRoute.Name == null)
            {
                return;
            }

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                string[] selectedText = listBoxRouteStops.GetItemText(listBoxRouteStops.SelectedItem).Split(new string[] { " --> " }, StringSplitOptions.None);

                string name = selectedText[0];
                string direction = selectedText[1];
                Stop theStop = DBEntities.Stop.FirstOrDefault(s => s.NameGroup == name && s.Direction == direction);

                DBEntities.Route.FirstOrDefault(r => r.Id == theRoute.Id).Stop.Remove(theStop);
                DBEntities.SaveChanges();

                theRoute = DBEntities.Route.FirstOrDefault(r => r.Id == theRoute.Id);
                PopulateRouteStops();
                PopulateOtherStops();
            }
        }

        private void buttonAddStop_Click(object sender, EventArgs e)
        {
            if (listBoxOtherStops.SelectedItem == null || theRoute.Name == null)
            {
                return;
            }

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                string[] selectedText = listBoxOtherStops.GetItemText(listBoxOtherStops.SelectedItem).Split(new string[] { " --> " }, StringSplitOptions.None);

                string name = selectedText[0];
                string direction = selectedText[1];
                Stop theStop = DBEntities.Stop.FirstOrDefault(s => s.NameGroup == name && s.Direction == direction);

                DBEntities.Route.FirstOrDefault(r => r.Id == theRoute.Id).Stop.Add(theStop);
                DBEntities.SaveChanges();

                theRoute = DBEntities.Route.FirstOrDefault(r => r.Id == theRoute.Id);
                PopulateRouteStops();
                PopulateOtherStops();
            }
        }
    }
}
