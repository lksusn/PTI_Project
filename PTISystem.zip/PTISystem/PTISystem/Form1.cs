﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTISystem
{
    public partial class MainWindow : Form
    {
        private string DBConnectionString;
        private SqlConnection DBConnection;

        public enum CRUDOption { Update, Add }

        public MainWindow()
        {
            InitializeComponent();

            DBConnectionString = ConfigurationManager.
                ConnectionStrings["PTISystem.Properties.Settings.PTI_dbConnectionString"].
                ConnectionString;
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {
            LoadViewsBox();
            SetVisibleWindow(groupBoxSmall);
        }

        private void SetVisibleWindow(GroupBox gb)
        {
            gb.Visible = true;
            bool b = (gb == groupBoxSmall) ?
                groupBoxLarge.Visible = false :
                groupBoxSmall.Visible = false;
        }

        private void LoadViewsBox()
        {
            comboBoxViews.Items.Add("Parks");
            comboBoxViews.Items.Add("Stops");
            comboBoxViews.Items.Add("Routes");

            comboBoxOptions.Visible = false;
            buttonShow.Visible = false;
        }

        private void LoadOptionsBox(string option)
        {
            comboBoxOptions.Items.Clear();
            comboBoxOptions.Visible = true;
            buttonShow.Visible = true;

            List<string> options = new List<string>();

            switch (option)
            {
                case "Parks":
                    options = LoadParkOptions();
                    break;
                case "Stops":
                    options = LoadStopOptions();
                    break;
                case "Routes":
                    options = LoadRouteOptions();
                    break;
            }

            foreach (var item in options)
            {
                comboBoxOptions.Items.Add(item);
            }

            comboBoxOptions.Text =
                (from op in options
                 select op).First();
        }

        private List<string> LoadParkOptions()
        {
            List<string> parkOptions = new List<string>();

            parkOptions.Add("All parks");

            return AddParkOptions(parkOptions);
        }

        private List<string> LoadStopOptions()
        {
            List<string> stopOptions = new List<string>();

            stopOptions.Add("All stops");

            return AddRouteOptions(stopOptions);
        }

        private List<string> LoadRouteOptions()
        {
            List<string> routeOptions = new List<string>();

            routeOptions.Add("All routes");

            return AddRouteOptions(AddParkOptions(routeOptions));
        }

        private List<string> AddRouteOptions(List<string> list)
        {
            using (DBConnection = new SqlConnection(DBConnectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT Name FROM Route", DBConnection))
            {
                DataTable stopTable = new DataTable();
                adapter.Fill(stopTable);

                list.AddRange((from DataRow row in stopTable.Rows
                               select ("Route \"" + (string)row["Name"]) + "\"").ToList());
            }

            return list;
        }

        private List<string> AddParkOptions(List<string> list)
        {
            using (DBConnection = new SqlConnection(DBConnectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT Name FROM Park", DBConnection))
            {
                DataTable parkTable = new DataTable();
                adapter.Fill(parkTable);

                list.AddRange((from DataRow row in parkTable.Rows
                               select ("Park \"" + (string)row["Name"]) + "\"").ToList());
            }

            return list;
        }

        private void PopulateDataGrid(string selection)
        {
            string tableSpecification = comboBoxViews.Text;
            List<string> options = new List<string>();

            if (!(selection.Split(' ').Take(1).First() == "All"))
            {
                options.Add(string.Join(" ", selection.Split(' ').Skip(1).ToArray()).Trim('\"'));
            }

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                switch (tableSpecification)
                {
                    case "Parks":

                        if (options.Count == 0)
                        {
                            options = ((DBEntities.Park).Select(x => x.Name)).ToList();
                        }

                        var queryPark =
                            (from service in DBEntities.Service
                             join route in DBEntities.Route
                                 on service.RouteID equals route.Id
                             join park in DBEntities.Park
                                 on service.ParkID equals park.Id
                             where options.Contains(park.Name)
                             group service by park.Id into services
                             select new
                             {
                                 ParkID = services.Key,
                                 ParkName = (DBEntities.Park).FirstOrDefault(p => p.Id == services.Key).Name,
                                 NumberOfRoutes = services.Count(),
                                 //BusRoutes = services.Where(s => s.Vehicle_Type == "Bus").Count(),
                                 //TrolleyBusRoutes = services.Where(s => s.Vehicle_Type == "Trolleybus").Count(),
                                 //TramRoutes = services.Where(s => s.Vehicle_Type == "Tram").Count(),
                                 //MetroRoutes = services.Where(s => s.Vehicle_Type == "Metro").Count(),
                                 TotalVehicles = (DBEntities.Vehicle).Where(s => s.ParkID == services.Key).Count(),
                                 VehiclesInRoutes = services.Select(s => s.Vehicle_Amout).Count(),
                                 Data = services.AsEnumerable()
                             }).ToList().Select(s => new
                             {
                                 s.ParkID,
                                 s.ParkName,
                                 Routes = s.Data.Aggregate("", (acc, t) => (acc == "" ? "" : acc + ", ") + t.Route.Name),
                                 s.NumberOfRoutes,
                                 //s.BusRoutes,
                                 //s.TrolleyBusRoutes,
                                 //s.TramRoutes,
                                 //s.MetroRoutes,
                                 s.TotalVehicles,
                                 s.VehiclesInRoutes
                             });

                        dataGridView.DataSource = queryPark.ToList();
                        break;
                    case "Stops":

                        if (options.Count == 0)
                        {
                            options = ((DBEntities.Route).Select(x => x.Name)).ToList();
                        }

                        var queryStop =
                        (from route in DBEntities.Route
                         from routeStop in route.Stop
                         join dbStop in DBEntities.Stop
                            on routeStop.Id equals dbStop.Id into st
                         from stop in st.DefaultIfEmpty()
                         where options.Contains(route.Name)
                         group stop by new { stop.Id, stop.NameGroup, stop.Direction, stop.Street } into stops
                         select new
                         {
                             StopID = stops.Key.Id,
                             StopName = stops.Key.NameGroup,
                             Direction = stops.Key.Direction,
                             Street = stops.Key.Street,
                             Data = stops.AsEnumerable(),
                             TotalRoutes = stops.Count()
                         }).ToList().Select(s => new
                         {
                             s.StopID,
                             s.StopName,
                             s.Direction,
                             s.Street,
                             Routes = s.Data.Aggregate("", (acc, t) => string.Join(", ", t.Route.Select(r => r.Name).ToArray())),
                             s.TotalRoutes
                         });

                        dataGridView.DataSource = queryStop.ToList();
                        break;
                    case "Routes":
                        if (options.Count == 0)
                        {
                            options = ((DBEntities.Route).Select(x => x.Name)).ToList();
                        }

                        var queryRoute =
                            from service in DBEntities.Service
                            join route in DBEntities.Route
                                on service.RouteID equals route.Id
                            join park in DBEntities.Park
                                on service.ParkID equals park.Id
                            where options.Contains(route.Name) || options.Contains(park.Name)
                            select new
                            {
                                RouteName = route.Name,
                                ParkName = park.Name,
                                TypeOfVehicles = service.Vehicle_Type,
                                NumberOfVehicles = service.Vehicle_Amout,
                                Duration = route.RunningTime,
                                NumberOfStops = route.Stop.Count()
                            };

                        dataGridView.DataSource = queryRoute.ToList();
                        break;
                }
            }

        }

        private void comboBoxViews_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadOptionsBox(((ComboBox)sender).Text);
        }

        private void comboBoxOptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetVisibleWindow(groupBoxLarge);
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            SetVisibleWindow(groupBoxSmall);
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void parksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboBoxViews.Text = "Parks";
            PopulateDataGrid("All parks");
            SetVisibleWindow(groupBoxLarge);
        }

        private void stopsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboBoxViews.Text = "Stops";
            PopulateDataGrid("All stops");
            SetVisibleWindow(groupBoxLarge);
        }

        private void routesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboBoxViews.Text = "Routes";
            PopulateDataGrid("All routes");
            SetVisibleWindow(groupBoxLarge);
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            PopulateDataGrid(comboBoxOptions.Text);
            SetVisibleWindow(groupBoxLarge);
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                foreach (DataGridViewRow row in dataGridView.SelectedRows)
                {
                    string itemName = "";

                    if (row.Cells[0].OwningColumn.Name == "StopID")
                    {
                        int stopId = (int)row.Cells[0].Value;
                        Stop theStop = DBEntities.Stop.FirstOrDefault(s => s.Id == stopId);
                        itemName = "Stop \"" + theStop.Id.ToString();

                        foreach (var route in DBEntities.Route)
                        {
                            if(route.Stop.Contains(theStop))
                            route.Stop.Remove(theStop);
                        }
                        DBEntities.Stop.Remove(theStop);

                    }
                    else if (row.Cells[0].OwningColumn.Name == "ParkID")
                    {
                        short parkId = (short)row.Cells[0].Value;
                        Park thePark = DBEntities.Park.FirstOrDefault(p => p.Id == parkId);
                        itemName = "Park \"" + thePark.Name.ToString();


                        var services = DBEntities.Service.Where(s => s.ParkID == thePark.Id).ToArray();

                        DBEntities.Service.RemoveRange(services);

                        foreach (var vehicle in thePark.Vehicle.ToArray())
                        {
                            DBEntities.Vehicle.Remove(vehicle);
                        }
                        foreach (var service in thePark.Service.ToArray())
                        {
                            thePark.Service.Remove(service);
                        }
                        DBEntities.Park.Remove(thePark);
                    }
                    else if(row.Cells[0].OwningColumn.Name == "RouteName")
                    {
                        string routeName = (string)row.Cells[0].Value;
                        Route theRoute = DBEntities.Route.FirstOrDefault(r => r.Name == routeName);
                        itemName = "Route \"" + theRoute.Name.ToString();
                        
                        foreach (var stop in theRoute.Stop.ToArray())
                        {
                            theRoute.Stop.Remove(stop);
                        }
                        foreach (var service in theRoute.Service.ToArray())
                        {
                            theRoute.Service.Remove(service);
                        }
                        DBEntities.Route.Remove(theRoute);
                    }

                    DialogResult dr = MessageBox.Show(
                        string.Format("Are you sure you want to delete {0}\"?", itemName),
                        "Delete?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        DBEntities.SaveChanges();
                    }
                }
            }

            PopulateDataGrid(comboBoxOptions.Text);
            SetVisibleWindow(groupBoxLarge);
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (comboBoxViews.Text == "Parks")
            {
                ParkOptions parkDialog = new ParkOptions(CRUDOption.Add, null);
                parkDialog.ShowDialog();
            }
            else if (comboBoxViews.Text == "Routes")
            {
                RouteOptions routeDialog = new RouteOptions(CRUDOption.Add, null);
                routeDialog.ShowDialog();
            }
            else if (comboBoxViews.Text == "Stops")
            {
                StopOptions stopDialog = new StopOptions(CRUDOption.Add, null);
                stopDialog.ShowDialog();
            }

            PopulateDataGrid(comboBoxOptions.Text);
            SetVisibleWindow(groupBoxLarge);

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                foreach (DataGridViewRow row in dataGridView.SelectedRows)
                {
                    if (row.Cells[0].OwningColumn.Name == "ParkID")
                    {
                        short parkId = (short)row.Cells[0].Value;
                        Park thePark = DBEntities.Park.FirstOrDefault(p => p.Id == parkId);

                        ParkOptions parkDialog = new ParkOptions(CRUDOption.Update, thePark);
                        parkDialog.ShowDialog();
                    }
                    else if (row.Cells[0].OwningColumn.Name == "RouteName")
                    {
                        string routeName = row.Cells[0].Value.ToString();
                        Route theRoute = DBEntities.Route.FirstOrDefault(r => r.Name == routeName);

                        RouteOptions routeDialog = new RouteOptions(CRUDOption.Update, theRoute);
                        routeDialog.ShowDialog();
                    }
                    else if (row.Cells[0].OwningColumn.Name == "StopID")
                    {
                        int stopId = (int)row.Cells[0].Value;
                        Stop theStop = DBEntities.Stop.FirstOrDefault(s => s.Id == stopId);

                        StopOptions stopDialog = new StopOptions(CRUDOption.Update, theStop);
                        stopDialog.ShowDialog();
                    }
                }
            }

            PopulateDataGrid(comboBoxOptions.Text);
            SetVisibleWindow(groupBoxLarge);
        }

        private void removeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonRemove.PerformClick();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonAdd.PerformClick();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonUpdate.PerformClick();
        }
    }
}
