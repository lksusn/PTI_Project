﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static PTISystem.MainWindow;

namespace PTISystem
{
    public partial class ParkOptions : Form
    {
        public string ParkName { get; private set; }
        public List<string> ParkRoutes { get; private set; }
        public List<string> FreeRoutes { get; private set; }
        public DialogResult Result { get; private set; }

        private CRUDOption option;
        private Park thePark;

        public ParkOptions(CRUDOption option, Park thePark)
        {
            InitializeComponent();
            Result = DialogResult.No;

            this.option = option;
            if (option == CRUDOption.Update)
            {
                this.thePark = thePark;
                textBoxParkName.Text = thePark.Name;

                PopulateParkRoutes();
                PopulateParkVehicles();
            }
            else
            {
                CreateNewPark();
            }
            PopulateFreeRoutes();
        }

        private void PopulateParkRoutes()
        {
            listBoxParkRoutes.Items.Clear();

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                foreach (var service in DBEntities.Service.Where(s => s.ParkID == thePark.Id))
                {
                    listBoxParkRoutes.Items.Add(service.Route.Name);
                }
            }
        }

        private void PopulateFreeRoutes()
        {
            listBoxFreeRoutes.Items.Clear();
            comboBoxServiceType.Items.Clear();

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                foreach (var route in DBEntities.Route.Where(r => r.Service.Count == 0))
                {
                    listBoxFreeRoutes.Items.Add(route.Name);
                }

                var vehiclesFromThisPark = DBEntities.Vehicle.
                    Where(v => v.ParkID == thePark.Id).
                    Select(x => x.Type).Distinct().ToArray();

                comboBoxServiceType.Items.AddRange(vehiclesFromThisPark);

                comboBoxServiceType.Text = "Select Type";
            }
        }

        private void PopulateParkVehicles()
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                var queryVehicles = DBEntities.Vehicle.Where(v => v.ParkID == thePark.Id).Select(s => new
                {
                    s.Id,
                    s.Type,
                    s.Tech_State,
                    Capacity = s.Capacity_Seat + s.Capacity_Standing
                });

                dataGridViewVehicles.DataSource = queryVehicles.ToList();
            }
        }

        private void buttonCommit_Click(object sender, EventArgs e)
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                DBEntities.Park.FirstOrDefault(p => p.Name == thePark.Name).Name = textBoxParkName.Text;

                if (string.IsNullOrEmpty(textBoxParkName.Text.Trim()))
                {
                    MessageBox.Show("Please provide name for the park.");
                    return;
                }
                else if (DBEntities.Park.Where(p => p.Id != thePark.Id).Select(p => p.Name).Contains(thePark.Name))
                {
                    MessageBox.Show("Park with such name already exists.");
                    return;
                }
                else DBEntities.SaveChanges();
            }

            Result = DialogResult.Yes;
            this.Close();
        }

        private void buttonDropLine_Click(object sender, EventArgs e)
        {
            if (listBoxParkRoutes.SelectedItem == null)
            {
                return; 
            }

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                string selectedText = listBoxParkRoutes.GetItemText(listBoxParkRoutes.SelectedItem);

                Route theRoute = DBEntities.Route.FirstOrDefault(r => r.Name == selectedText);

                Service theService = DBEntities.Service.FirstOrDefault(s => s.Route.Name == selectedText);

                DBEntities.Service.Remove(theService);
                DBEntities.SaveChanges();

                PopulateParkRoutes();
                PopulateFreeRoutes();
            }
        }

        private void buttonTakeLine_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(domainUpDownQuantity.Text) || string.IsNullOrEmpty(comboBoxServiceType.Text.Trim()))
            {
                return;
            }

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                string selectedRouteName = listBoxFreeRoutes.GetItemText(listBoxFreeRoutes.SelectedItem);
                if (!string.IsNullOrEmpty(selectedRouteName))
                {
                    Service newService = new Service();
                    newService.ParkID = thePark.Id;
                    newService.RouteID = DBEntities.Route.FirstOrDefault(r => r.Name == selectedRouteName).Id;
                    newService.Vehicle_Amout = Convert.ToInt16(domainUpDownQuantity.Text);
                    newService.Vehicle_Type = comboBoxServiceType.Text.Trim();

                    DBEntities.Service.Add(newService);
                    DBEntities.SaveChanges();

                    PopulateParkRoutes();
                    PopulateFreeRoutes();
                }
            }
        }

        private void CreateNewPark()
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                thePark = new Park();
                thePark.Name = "  ";

                DBEntities.Park.Add(thePark);
                DBEntities.SaveChanges();

                thePark = DBEntities.Park.FirstOrDefault(p => p.Name == "  ");
            }
        }

        private void comboBoxServiceType_SelectedIndexChanged(object sender, EventArgs e)
        {
            domainUpDownQuantity.Items.Clear();
            string selectedType = comboBoxServiceType.Text.Trim();

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                int i = 1;
                foreach (var vehicle in DBEntities.Vehicle.Where(v => v.Park.Id == thePark.Id && v.Type == selectedType))
                {
                    domainUpDownQuantity.Items.Add(i);
                    i++;
                }
            }

            domainUpDownQuantity.Text = "1";
        }

        private void buttonRemoveVehicle_Click(object sender, EventArgs e)
        {
            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                foreach (DataGridViewRow row in dataGridViewVehicles.SelectedRows)
                {
                    int vehicleId = Convert.ToInt32(row.Cells[0].Value);
                    Vehicle theVehicle = DBEntities.Vehicle.FirstOrDefault(v => v.Id == vehicleId);
                    string itemName = "Vehicle " + theVehicle.Id.ToString();

                    DBEntities.Vehicle.Remove(theVehicle);

                    DialogResult dr = MessageBox.Show(
                            string.Format("Are you sure you want to delete {0}\"?", itemName),
                            "Delete?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        DBEntities.SaveChanges();
                    }
                }

                PopulateParkVehicles();
            }
        }

        private void buttonBuy_Click(object sender, EventArgs e)
        {
            VehicleOptions newVehicleDialog = new VehicleOptions(thePark);
            newVehicleDialog.ShowDialog();

            PopulateParkVehicles();
            PopulateParkRoutes();
            PopulateFreeRoutes();
        }
    }
}
