﻿namespace PTISystem
{
    partial class StopOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCommit = new System.Windows.Forms.Button();
            this.textBoxStopName = new System.Windows.Forms.TextBox();
            this.labelStopName = new System.Windows.Forms.Label();
            this.textBoxStopDirection = new System.Windows.Forms.TextBox();
            this.labelStopDirection = new System.Windows.Forms.Label();
            this.textBoxStopStreet = new System.Windows.Forms.TextBox();
            this.labelStopStreet = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonCommit
            // 
            this.buttonCommit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonCommit.Location = new System.Drawing.Point(103, 127);
            this.buttonCommit.Name = "buttonCommit";
            this.buttonCommit.Size = new System.Drawing.Size(66, 24);
            this.buttonCommit.TabIndex = 15;
            this.buttonCommit.Text = "Done";
            this.buttonCommit.UseVisualStyleBackColor = true;
            this.buttonCommit.Click += new System.EventHandler(this.buttonCommit_Click);
            // 
            // textBoxStopName
            // 
            this.textBoxStopName.Location = new System.Drawing.Point(68, 6);
            this.textBoxStopName.Name = "textBoxStopName";
            this.textBoxStopName.Size = new System.Drawing.Size(191, 20);
            this.textBoxStopName.TabIndex = 14;
            this.textBoxStopName.TextChanged += new System.EventHandler(this.textBoxStopName_TextChanged);
            // 
            // labelStopName
            // 
            this.labelStopName.AutoSize = true;
            this.labelStopName.Location = new System.Drawing.Point(12, 13);
            this.labelStopName.Name = "labelStopName";
            this.labelStopName.Size = new System.Drawing.Size(38, 13);
            this.labelStopName.TabIndex = 13;
            this.labelStopName.Text = "Name:";
            // 
            // textBoxStopDirection
            // 
            this.textBoxStopDirection.Location = new System.Drawing.Point(68, 50);
            this.textBoxStopDirection.Name = "textBoxStopDirection";
            this.textBoxStopDirection.Size = new System.Drawing.Size(191, 20);
            this.textBoxStopDirection.TabIndex = 17;
            this.textBoxStopDirection.TextChanged += new System.EventHandler(this.textBoxStopDirection_TextChanged);
            // 
            // labelStopDirection
            // 
            this.labelStopDirection.AutoSize = true;
            this.labelStopDirection.Location = new System.Drawing.Point(12, 53);
            this.labelStopDirection.Name = "labelStopDirection";
            this.labelStopDirection.Size = new System.Drawing.Size(52, 13);
            this.labelStopDirection.TabIndex = 16;
            this.labelStopDirection.Text = "Direction:";
            // 
            // textBoxStopStreet
            // 
            this.textBoxStopStreet.Location = new System.Drawing.Point(68, 91);
            this.textBoxStopStreet.Name = "textBoxStopStreet";
            this.textBoxStopStreet.Size = new System.Drawing.Size(191, 20);
            this.textBoxStopStreet.TabIndex = 20;
            this.textBoxStopStreet.TextChanged += new System.EventHandler(this.textBoxStopStreet_TextChanged);
            // 
            // labelStopStreet
            // 
            this.labelStopStreet.AutoSize = true;
            this.labelStopStreet.Location = new System.Drawing.Point(12, 94);
            this.labelStopStreet.Name = "labelStopStreet";
            this.labelStopStreet.Size = new System.Drawing.Size(38, 13);
            this.labelStopStreet.TabIndex = 19;
            this.labelStopStreet.Text = "Street:";
            // 
            // StopOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(273, 163);
            this.Controls.Add(this.textBoxStopStreet);
            this.Controls.Add(this.labelStopStreet);
            this.Controls.Add(this.textBoxStopDirection);
            this.Controls.Add(this.labelStopDirection);
            this.Controls.Add(this.buttonCommit);
            this.Controls.Add(this.textBoxStopName);
            this.Controls.Add(this.labelStopName);
            this.Name = "StopOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StopOptions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCommit;
        private System.Windows.Forms.TextBox textBoxStopName;
        private System.Windows.Forms.Label labelStopName;
        private System.Windows.Forms.TextBox textBoxStopDirection;
        private System.Windows.Forms.Label labelStopDirection;
        private System.Windows.Forms.TextBox textBoxStopStreet;
        private System.Windows.Forms.Label labelStopStreet;
    }
}