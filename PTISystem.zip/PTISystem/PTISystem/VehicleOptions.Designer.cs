﻿namespace PTISystem
{
    partial class VehicleOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTechState = new System.Windows.Forms.Label();
            this.labelYear = new System.Windows.Forms.Label();
            this.buttonCommit = new System.Windows.Forms.Button();
            this.labelPark = new System.Windows.Forms.Label();
            this.labelTechValid = new System.Windows.Forms.Label();
            this.domainUpDownPark = new System.Windows.Forms.DomainUpDown();
            this.domainUpDownYear = new System.Windows.Forms.DomainUpDown();
            this.domainUpDownTechState = new System.Windows.Forms.DomainUpDown();
            this.dateTimePickerValidTill = new System.Windows.Forms.DateTimePicker();
            this.textBoxSeats = new System.Windows.Forms.TextBox();
            this.textBoxStanding = new System.Windows.Forms.TextBox();
            this.labelStandingSpace = new System.Windows.Forms.Label();
            this.labelSeats = new System.Windows.Forms.Label();
            this.domainUpDownType = new System.Windows.Forms.DomainUpDown();
            this.labelType = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelTechState
            // 
            this.labelTechState.AutoSize = true;
            this.labelTechState.Location = new System.Drawing.Point(14, 137);
            this.labelTechState.Name = "labelTechState";
            this.labelTechState.Size = new System.Drawing.Size(85, 13);
            this.labelTechState.TabIndex = 26;
            this.labelTechState.Text = "Technical State:";
            // 
            // labelYear
            // 
            this.labelYear.AutoSize = true;
            this.labelYear.Location = new System.Drawing.Point(12, 60);
            this.labelYear.Name = "labelYear";
            this.labelYear.Size = new System.Drawing.Size(32, 13);
            this.labelYear.TabIndex = 24;
            this.labelYear.Text = "Year:";
            // 
            // buttonCommit
            // 
            this.buttonCommit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonCommit.Location = new System.Drawing.Point(159, 207);
            this.buttonCommit.Name = "buttonCommit";
            this.buttonCommit.Size = new System.Drawing.Size(66, 24);
            this.buttonCommit.TabIndex = 23;
            this.buttonCommit.Text = "Done";
            this.buttonCommit.UseVisualStyleBackColor = true;
            this.buttonCommit.Click += new System.EventHandler(this.buttonCommit_Click);
            // 
            // labelPark
            // 
            this.labelPark.AutoSize = true;
            this.labelPark.Location = new System.Drawing.Point(12, 20);
            this.labelPark.Name = "labelPark";
            this.labelPark.Size = new System.Drawing.Size(32, 13);
            this.labelPark.TabIndex = 21;
            this.labelPark.Text = "Park:";
            // 
            // labelTechValid
            // 
            this.labelTechValid.AutoSize = true;
            this.labelTechValid.Location = new System.Drawing.Point(14, 176);
            this.labelTechValid.Name = "labelTechValid";
            this.labelTechValid.Size = new System.Drawing.Size(133, 13);
            this.labelTechValid.TabIndex = 28;
            this.labelTechValid.Text = "Technical Check Valid Till:";
            // 
            // domainUpDownPark
            // 
            this.domainUpDownPark.Location = new System.Drawing.Point(60, 17);
            this.domainUpDownPark.Name = "domainUpDownPark";
            this.domainUpDownPark.Size = new System.Drawing.Size(120, 20);
            this.domainUpDownPark.TabIndex = 29;
            // 
            // domainUpDownYear
            // 
            this.domainUpDownYear.Location = new System.Drawing.Point(60, 58);
            this.domainUpDownYear.Name = "domainUpDownYear";
            this.domainUpDownYear.Size = new System.Drawing.Size(120, 20);
            this.domainUpDownYear.TabIndex = 30;
            // 
            // domainUpDownTechState
            // 
            this.domainUpDownTechState.Location = new System.Drawing.Point(105, 135);
            this.domainUpDownTechState.Name = "domainUpDownTechState";
            this.domainUpDownTechState.Size = new System.Drawing.Size(120, 20);
            this.domainUpDownTechState.TabIndex = 31;
            // 
            // dateTimePickerValidTill
            // 
            this.dateTimePickerValidTill.Location = new System.Drawing.Point(162, 170);
            this.dateTimePickerValidTill.Name = "dateTimePickerValidTill";
            this.dateTimePickerValidTill.Size = new System.Drawing.Size(150, 20);
            this.dateTimePickerValidTill.TabIndex = 32;
            // 
            // textBoxSeats
            // 
            this.textBoxSeats.Location = new System.Drawing.Point(318, 17);
            this.textBoxSeats.Name = "textBoxSeats";
            this.textBoxSeats.Size = new System.Drawing.Size(35, 20);
            this.textBoxSeats.TabIndex = 33;
            // 
            // textBoxStanding
            // 
            this.textBoxStanding.Location = new System.Drawing.Point(318, 53);
            this.textBoxStanding.Name = "textBoxStanding";
            this.textBoxStanding.Size = new System.Drawing.Size(35, 20);
            this.textBoxStanding.TabIndex = 34;
            // 
            // labelStandingSpace
            // 
            this.labelStandingSpace.AutoSize = true;
            this.labelStandingSpace.Location = new System.Drawing.Point(226, 59);
            this.labelStandingSpace.Name = "labelStandingSpace";
            this.labelStandingSpace.Size = new System.Drawing.Size(86, 13);
            this.labelStandingSpace.TabIndex = 36;
            this.labelStandingSpace.Text = "Standing Space:";
            // 
            // labelSeats
            // 
            this.labelSeats.AutoSize = true;
            this.labelSeats.Location = new System.Drawing.Point(250, 19);
            this.labelSeats.Name = "labelSeats";
            this.labelSeats.Size = new System.Drawing.Size(37, 13);
            this.labelSeats.TabIndex = 35;
            this.labelSeats.Text = "Seats:";
            // 
            // domainUpDownType
            // 
            this.domainUpDownType.Location = new System.Drawing.Point(60, 100);
            this.domainUpDownType.Name = "domainUpDownType";
            this.domainUpDownType.Size = new System.Drawing.Size(120, 20);
            this.domainUpDownType.TabIndex = 38;
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(12, 102);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(34, 13);
            this.labelType.TabIndex = 37;
            this.labelType.Text = "Type:";
            // 
            // VehicleOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 239);
            this.Controls.Add(this.domainUpDownType);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.labelStandingSpace);
            this.Controls.Add(this.labelSeats);
            this.Controls.Add(this.textBoxStanding);
            this.Controls.Add(this.textBoxSeats);
            this.Controls.Add(this.dateTimePickerValidTill);
            this.Controls.Add(this.domainUpDownTechState);
            this.Controls.Add(this.domainUpDownYear);
            this.Controls.Add(this.domainUpDownPark);
            this.Controls.Add(this.labelTechValid);
            this.Controls.Add(this.labelTechState);
            this.Controls.Add(this.labelYear);
            this.Controls.Add(this.buttonCommit);
            this.Controls.Add(this.labelPark);
            this.Name = "VehicleOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VehicleOptions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTechState;
        private System.Windows.Forms.Label labelYear;
        private System.Windows.Forms.Button buttonCommit;
        private System.Windows.Forms.Label labelPark;
        private System.Windows.Forms.Label labelTechValid;
        private System.Windows.Forms.DomainUpDown domainUpDownPark;
        private System.Windows.Forms.DomainUpDown domainUpDownYear;
        private System.Windows.Forms.DomainUpDown domainUpDownTechState;
        private System.Windows.Forms.DateTimePicker dateTimePickerValidTill;
        private System.Windows.Forms.TextBox textBoxSeats;
        private System.Windows.Forms.TextBox textBoxStanding;
        private System.Windows.Forms.Label labelStandingSpace;
        private System.Windows.Forms.Label labelSeats;
        private System.Windows.Forms.DomainUpDown domainUpDownType;
        private System.Windows.Forms.Label labelType;
    }
}