﻿namespace PTISystem
{
    partial class ParkOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelParkName = new System.Windows.Forms.Label();
            this.textBoxParkName = new System.Windows.Forms.TextBox();
            this.labelParkRoutes = new System.Windows.Forms.Label();
            this.listBoxParkRoutes = new System.Windows.Forms.ListBox();
            this.listBoxFreeRoutes = new System.Windows.Forms.ListBox();
            this.labelAllRoutes = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonDropLine = new System.Windows.Forms.Button();
            this.buttonTakeLine = new System.Windows.Forms.Button();
            this.buttonBuy = new System.Windows.Forms.Button();
            this.buttonRemoveVehicle = new System.Windows.Forms.Button();
            this.buttonCommit = new System.Windows.Forms.Button();
            this.dataGridViewVehicles = new System.Windows.Forms.DataGridView();
            this.comboBoxServiceType = new System.Windows.Forms.ComboBox();
            this.domainUpDownQuantity = new System.Windows.Forms.DomainUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVehicles)).BeginInit();
            this.SuspendLayout();
            // 
            // labelParkName
            // 
            this.labelParkName.AutoSize = true;
            this.labelParkName.Location = new System.Drawing.Point(12, 16);
            this.labelParkName.Name = "labelParkName";
            this.labelParkName.Size = new System.Drawing.Size(63, 13);
            this.labelParkName.TabIndex = 0;
            this.labelParkName.Text = "Park Name:";
            // 
            // textBoxParkName
            // 
            this.textBoxParkName.Location = new System.Drawing.Point(81, 13);
            this.textBoxParkName.Name = "textBoxParkName";
            this.textBoxParkName.Size = new System.Drawing.Size(253, 20);
            this.textBoxParkName.TabIndex = 1;
            // 
            // labelParkRoutes
            // 
            this.labelParkRoutes.AutoSize = true;
            this.labelParkRoutes.Location = new System.Drawing.Point(13, 51);
            this.labelParkRoutes.Name = "labelParkRoutes";
            this.labelParkRoutes.Size = new System.Drawing.Size(69, 13);
            this.labelParkRoutes.TabIndex = 2;
            this.labelParkRoutes.Text = "Park Routes:";
            // 
            // listBoxParkRoutes
            // 
            this.listBoxParkRoutes.FormattingEnabled = true;
            this.listBoxParkRoutes.Location = new System.Drawing.Point(13, 68);
            this.listBoxParkRoutes.Name = "listBoxParkRoutes";
            this.listBoxParkRoutes.Size = new System.Drawing.Size(145, 121);
            this.listBoxParkRoutes.TabIndex = 3;
            // 
            // listBoxFreeRoutes
            // 
            this.listBoxFreeRoutes.FormattingEnabled = true;
            this.listBoxFreeRoutes.Location = new System.Drawing.Point(235, 67);
            this.listBoxFreeRoutes.Name = "listBoxFreeRoutes";
            this.listBoxFreeRoutes.Size = new System.Drawing.Size(151, 121);
            this.listBoxFreeRoutes.TabIndex = 4;
            // 
            // labelAllRoutes
            // 
            this.labelAllRoutes.AutoSize = true;
            this.labelAllRoutes.Location = new System.Drawing.Point(232, 51);
            this.labelAllRoutes.Name = "labelAllRoutes";
            this.labelAllRoutes.Size = new System.Drawing.Size(68, 13);
            this.labelAllRoutes.TabIndex = 5;
            this.labelAllRoutes.Text = "Free Routes:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Park Vehicles:";
            // 
            // buttonDropLine
            // 
            this.buttonDropLine.Location = new System.Drawing.Point(173, 97);
            this.buttonDropLine.Name = "buttonDropLine";
            this.buttonDropLine.Size = new System.Drawing.Size(46, 24);
            this.buttonDropLine.TabIndex = 8;
            this.buttonDropLine.Text = "-->";
            this.buttonDropLine.UseVisualStyleBackColor = true;
            this.buttonDropLine.Click += new System.EventHandler(this.buttonDropLine_Click);
            // 
            // buttonTakeLine
            // 
            this.buttonTakeLine.Location = new System.Drawing.Point(173, 127);
            this.buttonTakeLine.Name = "buttonTakeLine";
            this.buttonTakeLine.Size = new System.Drawing.Size(46, 24);
            this.buttonTakeLine.TabIndex = 9;
            this.buttonTakeLine.Text = "<--";
            this.buttonTakeLine.UseVisualStyleBackColor = true;
            this.buttonTakeLine.Click += new System.EventHandler(this.buttonTakeLine_Click);
            // 
            // buttonBuy
            // 
            this.buttonBuy.Location = new System.Drawing.Point(81, 312);
            this.buttonBuy.Name = "buttonBuy";
            this.buttonBuy.Size = new System.Drawing.Size(98, 23);
            this.buttonBuy.TabIndex = 10;
            this.buttonBuy.Text = "Buy New";
            this.buttonBuy.UseVisualStyleBackColor = true;
            this.buttonBuy.Click += new System.EventHandler(this.buttonBuy_Click);
            // 
            // buttonRemoveVehicle
            // 
            this.buttonRemoveVehicle.Location = new System.Drawing.Point(199, 312);
            this.buttonRemoveVehicle.Name = "buttonRemoveVehicle";
            this.buttonRemoveVehicle.Size = new System.Drawing.Size(101, 23);
            this.buttonRemoveVehicle.TabIndex = 11;
            this.buttonRemoveVehicle.Text = "Remove Selected";
            this.buttonRemoveVehicle.UseVisualStyleBackColor = true;
            this.buttonRemoveVehicle.Click += new System.EventHandler(this.buttonRemoveVehicle_Click);
            // 
            // buttonCommit
            // 
            this.buttonCommit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttonCommit.Location = new System.Drawing.Point(340, 9);
            this.buttonCommit.Name = "buttonCommit";
            this.buttonCommit.Size = new System.Drawing.Size(46, 24);
            this.buttonCommit.TabIndex = 12;
            this.buttonCommit.Text = "Done";
            this.buttonCommit.UseVisualStyleBackColor = true;
            this.buttonCommit.Click += new System.EventHandler(this.buttonCommit_Click);
            // 
            // dataGridViewVehicles
            // 
            this.dataGridViewVehicles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVehicles.Location = new System.Drawing.Point(12, 223);
            this.dataGridViewVehicles.Name = "dataGridViewVehicles";
            this.dataGridViewVehicles.Size = new System.Drawing.Size(374, 83);
            this.dataGridViewVehicles.TabIndex = 13;
            // 
            // comboBoxServiceType
            // 
            this.comboBoxServiceType.FormattingEnabled = true;
            this.comboBoxServiceType.Location = new System.Drawing.Point(286, 196);
            this.comboBoxServiceType.Name = "comboBoxServiceType";
            this.comboBoxServiceType.Size = new System.Drawing.Size(100, 21);
            this.comboBoxServiceType.TabIndex = 14;
            this.comboBoxServiceType.SelectedIndexChanged += new System.EventHandler(this.comboBoxServiceType_SelectedIndexChanged);
            // 
            // domainUpDownQuantity
            // 
            this.domainUpDownQuantity.Location = new System.Drawing.Point(234, 197);
            this.domainUpDownQuantity.Name = "domainUpDownQuantity";
            this.domainUpDownQuantity.Size = new System.Drawing.Size(46, 20);
            this.domainUpDownQuantity.TabIndex = 15;
            // 
            // ParkOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 344);
            this.Controls.Add(this.domainUpDownQuantity);
            this.Controls.Add(this.comboBoxServiceType);
            this.Controls.Add(this.dataGridViewVehicles);
            this.Controls.Add(this.buttonCommit);
            this.Controls.Add(this.buttonRemoveVehicle);
            this.Controls.Add(this.buttonBuy);
            this.Controls.Add(this.buttonTakeLine);
            this.Controls.Add(this.buttonDropLine);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelAllRoutes);
            this.Controls.Add(this.listBoxFreeRoutes);
            this.Controls.Add(this.listBoxParkRoutes);
            this.Controls.Add(this.labelParkRoutes);
            this.Controls.Add(this.textBoxParkName);
            this.Controls.Add(this.labelParkName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ParkOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ParkOptions";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVehicles)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelParkName;
        private System.Windows.Forms.TextBox textBoxParkName;
        private System.Windows.Forms.Label labelParkRoutes;
        private System.Windows.Forms.ListBox listBoxParkRoutes;
        private System.Windows.Forms.ListBox listBoxFreeRoutes;
        private System.Windows.Forms.Label labelAllRoutes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonDropLine;
        private System.Windows.Forms.Button buttonTakeLine;
        private System.Windows.Forms.Button buttonBuy;
        private System.Windows.Forms.Button buttonRemoveVehicle;
        private System.Windows.Forms.Button buttonCommit;
        private System.Windows.Forms.DataGridView dataGridViewVehicles;
        private System.Windows.Forms.ComboBox comboBoxServiceType;
        private System.Windows.Forms.DomainUpDown domainUpDownQuantity;
    }
}