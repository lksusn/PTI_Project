﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTISystem
{
    public partial class VehicleOptions : Form
    {
        public DialogResult Result { get; private set; }
        private Vehicle theVehicle;
        private Park thePark;

        public VehicleOptions(Park thePark)
        {
            InitializeComponent();

            this.thePark = thePark;

            PopulateDomainParks();
            PopulateDomainYear();
            PopulateDomainState();
            PopulateDomainType();

            Result = DialogResult.Cancel;
            theVehicle = new Vehicle();
        }

        private void PopulateDomainParks()
        {
            domainUpDownPark.Items.Add(thePark.Name);
            domainUpDownPark.Text = thePark.Name;
        }

        private void PopulateDomainYear()
        {
            int currentYear = DateTime.Today.Year - 1;
            int lastAcceptable = 1934;

            domainUpDownYear.Text = currentYear.ToString();
            for (int i = currentYear; i >= lastAcceptable; i--)
            {
                domainUpDownYear.Items.Add(i);
            }
        }

        private void PopulateDomainState()
        {
            domainUpDownTechState.Items.Add("Excellent");
            domainUpDownTechState.Items.Add("Good");
            domainUpDownTechState.Items.Add("Stable");
            domainUpDownTechState.Items.Add("Poor");
            domainUpDownTechState.Text = "Excellent";
        }

        private void PopulateDomainType()
        {
            domainUpDownType.Items.Add("Bus");
            domainUpDownType.Items.Add("Trolleybus");
            domainUpDownType.Items.Add("Tram");
            domainUpDownType.Items.Add("Metro");
            domainUpDownType.Text = "Bus";
        }

        private void buttonCommit_Click(object sender, EventArgs e)
        {
            if (!domainUpDownPark.Items.Contains(domainUpDownPark.Text))
            {
                MessageBox.Show("Invalid park name.");
                return;
            }

            if (!domainUpDownYear.Items.Contains(Convert.ToInt32(domainUpDownYear.Text)))
            {
                MessageBox.Show("Invalid year selected.");
                return;
            }

            if (!domainUpDownTechState.Items.Contains(domainUpDownTechState.Text))
            {
                MessageBox.Show("Invalid technical state selected.");
                return;
            }

            if (!domainUpDownType.Items.Contains(domainUpDownType.Text))
            {
                MessageBox.Show("Invalid type selected.");
                return;
            }

            if (dateTimePickerValidTill.Value <= DateTime.Today)
            {
                MessageBox.Show("Invalid technical validation date selected.");
                return;
            }

            int i;
            if (!int.TryParse(textBoxSeats.Text, out i) || i <= 5)
            {
                MessageBox.Show("Invalid seat number selected.");
                return;
            }

            if (!int.TryParse(textBoxStanding.Text, out i) || i <= 5)
            {
                MessageBox.Show("Invalid standing space number selected.");
                return;
            }

            using (PTI_dbEntities DBEntities = new PTI_dbEntities())
            {
                theVehicle.ParkID = DBEntities.Park.FirstOrDefault(p => p.Name == domainUpDownPark.Text).Id;
                theVehicle.Year = Convert.ToInt16(domainUpDownYear.Text);
                theVehicle.Tech_State = domainUpDownTechState.Text;
                theVehicle.Tech_ValidTill = dateTimePickerValidTill.Value;
                theVehicle.Type = domainUpDownType.Text;
                theVehicle.Capacity_Seat = textBoxSeats.Text;
                theVehicle.Capacity_Standing = Convert.ToInt16(textBoxStanding.Text);

                DBEntities.Vehicle.Add(theVehicle);
                DBEntities.SaveChanges();
            }

            Result = DialogResult.OK;
            this.Close();
        }
    }
}
